Anemometer by DigitalUrban on Thingiverse: https://www.thingiverse.com/thing:333741

Summary:
Anemometer made for an M8 bearing to minimise friction, the bearing fits inside the support.stl file. Note a modified version can now be found at http://www.thingiverse.com/thing:338464  The centre goes through and rests on top of the bearing, providing an anemometer that responds to minimum wind speeds. The wind cups (remixed from the Coffee Cup Scoop on Thingiverse) slot into the central hub. Created in SketchUp.